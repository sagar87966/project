class PackOne:
    def __init__(self):
        self.name = 'PackOne'

    def do(self):
        return 'My name is {}'.format(self.name)